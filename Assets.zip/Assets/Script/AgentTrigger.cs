using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
public class AgentTrigger : MonoBehaviour
{
    //Attach File to TriggerBox to make Agent stop
    public Material red;
    public Material green;
    public bool isRed = true;
    public int timer = 0;
    public GameObject Stop;
    void Start() { }
    void Update()
    {
        if (isRed == true)
        {
            timer++;
            if (timer == 300)
            {
                Stop.GetComponent<Renderer>().material = green;
                timer = 0;
                isRed = false;
            }
            
        }
        else if (isRed == false)
        {
            timer++;
            if (timer == 300)
            {
                Stop.GetComponent<Renderer>().material = red;
                timer = 0;
                isRed = true;
            }

        }
    }


    private void OnTriggerEnter(Collider other)
    {

        if (other.gameObject.tag == "Agent")
        {
            if (isRed == true)
            {
                other.gameObject.GetComponent<NavMeshAgent>().isStopped = true;
                print("Agent");
            }
            else if (isRed == false)
            {
                other.gameObject.GetComponent<NavMeshAgent>().isStopped = false;
            }
        }

    }
    private void OnTriggerStay(Collider other)
    {
        if (other.gameObject.tag == "Agent")
        {
            if (isRed == true)
            {
                other.gameObject.GetComponent<NavMeshAgent>().isStopped = true;
                print("Agent");
            }
            else if (isRed == false)
            {
                other.gameObject.GetComponent<NavMeshAgent>().isStopped = false;
            }
        }

    }

    void OnTriggerExit(Collider other) {
        other.gameObject.GetComponent<NavMeshAgent>().isStopped = false;

    }
}