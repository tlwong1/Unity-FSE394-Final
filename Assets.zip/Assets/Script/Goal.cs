using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Goal : MonoBehaviour
{
    public Transform[] locations; // Array of potential locations to go after reaching this goal
}
