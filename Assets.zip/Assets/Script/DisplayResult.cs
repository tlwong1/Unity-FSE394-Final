using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using System.IO;

public class DisplayResult : MonoBehaviour
{
    // *** Attach to the Text (TMPro) object to display the data.txt

    void Start()
    {
        string filename = Application.dataPath + "/data.txt";
        if (File.Exists(filename))
        {
            StreamReader sr = File.OpenText(filename);
            string aNum = sr.ReadLine();
            string aTime = sr.ReadLine();
            sr.Close();

            int a = int.Parse(aNum);
            float b = float.Parse(aTime);
            GetComponent<TMPro.TextMeshProUGUI>().text = aNum + "\n";
            GetComponent<TMPro.TextMeshProUGUI>().text += aTime + "\n";
            GetComponent<TMPro.TextMeshProUGUI>().text += "Average Time: " + (b / a);
        }
        else
        {
            Debug.Log("Could not open the file " + filename + " for reading");
            return;
        }
    }
}