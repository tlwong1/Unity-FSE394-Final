using UnityEngine;
using TMPro; // Import TextMeshPro namespace

public class TriggerCounter : MonoBehaviour
{
    public int triggerCount = 0; // Counter variable to keep track of the number of triggers
    public TextMeshProUGUI triggerCountText; // Reference to TextMeshProUGUI component

    // This method is called when the Collider other enters the trigger
    void OnTriggerEnter(Collider other)
    {
        // Increment the counter
        //triggerCount++;

        // Optionally, you can check for specific tags if you want to count only specific triggers
        if (other.gameObject.tag == "Agent")
        {
             triggerCount++;
        }

        // Display the count in the TextMeshPro text
        if (triggerCountText != null)
        {
            triggerCountText.text = triggerCount.ToString();
        }

        // Optionally, log the count to the console
        Debug.Log("Trigger Count: " + triggerCount);
    }
}
