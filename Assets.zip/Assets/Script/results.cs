using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System.IO;

public class results : MonoBehaviour
{
    public TextMeshProUGUI textMeshPro;
    public string fileName = "data.txt";

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        result(fileName);
    }

    public void result(string fileName) {
        string path = Path.Combine(Application.dataPath, fileName);
        string fileContents = File.ReadAllText(path);
        textMeshPro.text = fileContents;
    }
}
