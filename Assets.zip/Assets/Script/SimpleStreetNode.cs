using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SimpleStreetNode : MonoBehaviour
{
    public Transform[] nextNodes; // drag and drop in Unity
    public Vector3[] directions; // auto set
    public bool isCafe = false;

    public int counter = 0;
    void Start()
    {
        if (nextNodes != null)
        {
            directions = new Vector3[nextNodes.Length];
            for (int i = 0; i < nextNodes.Length; i++)
            {
                directions[i] = Vector3.Normalize(nextNodes[i].position - transform.position);
            }
        }
    }

    void OnTriggerEnter(Collider other) {
        if (other.gameObject.tag == "Agent") {
            counter++;
        }
    }
}
