using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.IO;
public class FileIO : MonoBehaviour
{
// Attach this file to Manager Object
string fileName;
SimpleTimer timer;
void Start(){ 
    Time.timeScale = 0;
    PlayerPrefs.SetInt("AgentNum", 0);
}
void Update(){ }
// Use for Button to write and read "output.txt" file
public void FSE394WriteFile()
    {
        fileName = Application.dataPath + "/data.txt";

        int starCounter = GameObject.Find("goal").GetComponent<TriggerCounter>().triggerCount;
        int viewCounter = GameObject.Find("view area").GetComponent<TriggerCounter>().triggerCount;
        StreamWriter sw = File.CreateText(fileName);
        sw.WriteLine("# of Starbucks visitors: {0}", starCounter);
        sw.WriteLine("# of Viewing Area visitors: {0}", viewCounter);
        sw.WriteLine();
        sw.Close();
        Debug.Log("File written to: " + fileName);

        //timer = GameObject.Find("Timer").GetComponent<SimpleTimer>();
        /*if (File.Exists(fileName))
        {
            Debug.Log(fileName + " already exists.");
            return;
        }*/
       /* StreamWriter sw = File.CreateText(fileName);
        int num = PlayerPrefs.GetInt("AgentNum");
        sw.WriteLine("Num of Agents: {0}", num);
        sw.WriteLine("Saved Time: {0}", timer.message.text);
        float avg = float.Parse(timer.message.text) / num;
        sw.WriteLine("Average Time: {0}", avg);
        sw.WriteLine();
        sw.Close();
        Debug.Log("File written to: " + fileName);*/
    }
public void FSE394ReadFile()
{
fileName = Application.dataPath + "/output.txt";
if(File.Exists(fileName))
{
StreamReader sr = File.OpenText(fileName);
string line = sr.ReadLine();
while(line != null)
{
Debug.Log(line);
line = sr.ReadLine();
}
}
else
{
Debug.Log("Could not open the file:" + fileName + " for reading");
return;
}
}
// Use for Button to stop/resume Time
public void FSE394TimeChange()
{
if (Time.timeScale != 0) Time.timeScale = 0;
else Time.timeScale = 1;
}
// Use for Slider named "TimeScaleSlider" (Does not work for "Slider"
public void FSE394TimeScaleSlider() {
GameObject slider = GameObject.Find("TimeScaleSlider");
Time.timeScale = slider.GetComponent<UnityEngine.UI.Slider>().value;
}
// Use for Button to change the Scene named "Day6"
public void FSE394ProjectScene()
{
SceneManager.LoadScene("Final Project");
}

public void FSE394TitleScene()
{
SceneManager.LoadScene("UI testing");
}

public void FSE394ResultsScene()
{
SceneManager.LoadScene("Result UI");
}
}