using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarSpawn : MonoBehaviour
{
    public Transform prefab_Car;
    //public Transform StreetNode;
    int step = 0;

    void Start(){ }

    // Update is called once per frame
    void Update()
    {
        step++;
        //Vector3 direction = Vector3.Normalize(Tranform.position - StreetNode.position);
        //transform.rotation = Quaternion.LookRotation(direction);
        if (step == 1000)
        {
            step = 0;
            Instantiate(prefab_Car, transform.position, transform.rotation);
        }

    }
}