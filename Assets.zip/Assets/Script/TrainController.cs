using UnityEngine;

public class TrainController : MonoBehaviour
{
    public Transform[] targets;
    public Transform station;
    public float speed = 2.0f;
    public float stopDuration = 1.0f;

    private int currentTargetIndex = 0;
    private bool isStopped = false;
    private float stopTimer = 0.0f;

    public delegate void TrainReachedEnd();
    public static event TrainReachedEnd OnTrainReachedEnd;

    void Start()
    {
        if (targets.Length > 0)
        {
            transform.position = targets[0].position;
        }
    }

    void Update()
    {
        if (isStopped)
        {
            stopTimer -= Time.deltaTime;
            if (stopTimer <= 0)
            {
                isStopped = false;
            }
        }
        else
        {
            MoveTrain();
        }
    }

    void MoveTrain()
    {
        if (targets.Length == 0) return;

        Vector3 currentTarget = targets[currentTargetIndex].position;
        transform.position = Vector3.MoveTowards(transform.position, currentTarget, speed * Time.deltaTime);

        if (Vector3.Distance(transform.position, station.position) < 1.0f)
        {
            isStopped = true;
            stopTimer = stopDuration;
        }

        if (Vector3.Distance(transform.position, currentTarget) < 0.1f)
        {
            currentTargetIndex = (currentTargetIndex + 1) % targets.Length;
            if (currentTargetIndex == 0 && OnTrainReachedEnd != null)
            {
                OnTrainReachedEnd();
                Destroy(gameObject);
            }
        }
    }
}
