using UnityEngine;

public class TrainSpawn : MonoBehaviour
{
    public GameObject trainPrefab;
    public Transform[] targets;
    public Transform station;

    void OnEnable()
    {
        TrainController.OnTrainReachedEnd += SpawnNewTrain;
    }

    void OnDisable()
    {
        TrainController.OnTrainReachedEnd -= SpawnNewTrain;
    }

    void Start()
    {
        SpawnNewTrain();
    }

    void SpawnNewTrain()
    {
        GameObject newTrain = Instantiate(trainPrefab, targets[0].position, Quaternion.identity);
        TrainController trainController = newTrain.GetComponent<TrainController>();
        trainController.targets = targets;
        trainController.station = station;
    }
}
