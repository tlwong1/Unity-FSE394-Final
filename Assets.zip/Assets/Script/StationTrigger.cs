using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StationTrigger : MonoBehaviour {
    public GameObject correctObject;
    public GameObject sendToObject;
    public Material red_material;
    public Material green_material;
    
    void OnTriggerEnter(Collider other) {
        if (other.gameObject == correctObject) {
            MoveMulti moveScript = other.gameObject.GetComponent<MoveMulti>();
            if (moveScript != null) {
                moveScript.StartStopping = true;
                sendToObject.GetComponent<Renderer>().material = red_material;
                //sendToObject.GetComponent<Renderer>().enabled = true;
            }
            Debug.Log("Enter");
        }
    }

    void OnTriggerExit(Collider other) {
        if (other.gameObject == correctObject) {
            sendToObject.GetComponent<Renderer>().material = green_material;
            //sendToObject.GetComponent<Renderer>().enabled = false;
            Debug.Log("Exit");
        }
    }
}
