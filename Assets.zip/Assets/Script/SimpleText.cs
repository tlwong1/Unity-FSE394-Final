using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SimpleText : MonoBehaviour
{
    public Text message;
    public string AgentNumKey = "AgentNum";

    // Start is called before the first frame update
    void Start()
    {
        message = GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        int agentNum = PlayerPrefs.GetInt(AgentNumKey, 0); // Get current value or 0 if not set
        message.text = "Agents Destroyed: " + agentNum.ToString();
    }
}
