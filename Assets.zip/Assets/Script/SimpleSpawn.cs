using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SimpleSpawn : MonoBehaviour
{
    int step = 0;
    public Transform Agent;
    public Slider spawnRateSlider; // Reference to the spawn rate slider
    public Slider groupSizeSlider; // Reference to the group size slider
    private int spawnRate;         // Variable to hold the spawn rate
    private int groupSize;         // Variable to hold the group size

    // Start is called before the first frame update
    void Start()
    {
        // Find the sliders in the scene and assign them to the references
        spawnRateSlider = GameObject.Find("SpawnRateSlider").GetComponent<Slider>();
        groupSizeSlider = GameObject.Find("GroupSizeSlider").GetComponent<Slider>();
    }

    // Update is called once per frame
    void Update()
    {
        // Update spawnRate and groupSize based on slider values
        spawnRate = Mathf.RoundToInt(spawnRateSlider.value);
        groupSize = Mathf.RoundToInt(groupSizeSlider.value);

        step++;
        if (step >= spawnRate)
        {
            step = 0;
            for (int i = 0; i < groupSize; i++)
            {
                Instantiate(Agent, transform.position, Quaternion.identity);
            }
        }
    }
}
