using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class AgentMover : MonoBehaviour
{
    private NavMeshAgent agent;
    private Transform[] currentLocations;
    private bool isPaused = false;
    private int pauseFrames = 0;
    private const int pauseDuration = 60;

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        PickRandomGoal();
    }

    void Update()
    {
        if (isPaused)
        {
            pauseFrames++;
            if (pauseFrames >= pauseDuration)
            {
                isPaused = false;
                pauseFrames = 0;
                PickNewLocation();
                agent.isStopped = false; // Resume movement
            }
            return;
        }

        if (agent.remainingDistance <= agent.stoppingDistance && !agent.pathPending)
        {
            OnReachLocation();
        }
    }

    void PickRandomGoal()
    {
        GameObject[] goals = GameObject.FindGameObjectsWithTag("Goal");
        if (goals.Length == 0)
        {
            Destroy(gameObject);
            return;
        }

        int randomIndex = Random.Range(0, goals.Length);
        GameObject randomGoal = goals[randomIndex];

        if (randomGoal != null)
        {
            Goal goalComponent = randomGoal.GetComponent<Goal>();
            if (goalComponent != null && goalComponent.locations.Length > 0)
            {
                currentLocations = goalComponent.locations;
                PickNewLocation();
            }
            else
            {
                Destroy(gameObject);
            }

            // Log the position of the random goal
            Debug.Log("The position of the random goal is: " + randomGoal.transform.position);
        }
    }

    void PickNewLocation()
    {
        if (currentLocations == null || currentLocations.Length == 0)
        {
            Destroy(gameObject);
            return;
        }

        int randomIndex = Random.Range(0, currentLocations.Length);
        agent.SetDestination(currentLocations[randomIndex].position);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("StreetNode"))
        {
            SimpleStreetNode node = other.gameObject.GetComponent<SimpleStreetNode>();
            if (node != null)
            {
                if (node.isCafe)
                {
                    isPaused = true;
                    agent.isStopped = true;
                }
                else if (node.nextNodes.Length == 0)
                {
                    Destroy(gameObject);
                }
                else
                {
                    currentLocations = node.nextNodes;
                    PickNewLocation();
                }
            }
        }
    }

    void OnReachLocation()
    {
        Collider[] colliders = Physics.OverlapSphere(transform.position, 1f);
        foreach (var collider in colliders)
        {
            if (collider.CompareTag("StreetNode"))
            {
                SimpleStreetNode node = collider.GetComponent<SimpleStreetNode>();
                if (node != null)
                {
                    if (node.isCafe)
                    {
                        isPaused = true;
                        agent.isStopped = true;
                    }
                    else if (node.nextNodes.Length == 0)
                    {
                        Destroy(gameObject);
                    }
                    else
                    {
                        currentLocations = node.nextNodes;
                        PickNewLocation();
                    }
                }
                return;
            }
        }
    }
}
