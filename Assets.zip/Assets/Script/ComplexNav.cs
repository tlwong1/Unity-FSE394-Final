using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI; // add new library

public class ComplexNav : MonoBehaviour
{
    // Start is called before the first frame update
    public Transform goal;
    public Transform[] nextNodes; // drag and drop in Unity
    int step = 0;

    void Start() {
        GameObject[] goals = GameObject.FindGameObjectsWithTag("Goal");
        int rand = Random.Range(0, goals.Length);goal = goals[rand].transform;
        //mainRand = rand;

        NavMeshAgent agent = GetComponent<NavMeshAgent>();
        agent.SetDestination(goal.position);
    }



    // Update is called once per frame
    void Update()
    {
        //step++;
        /*GameObject[] goals = GameObject.FindGameObjectsWithTag("Goal");
        
        float dis = Vector3.Distance(goal.position, this.transform.position);
        if (dis < 1)
        {
            if (goals[mainRand].GetComponent<SimpleStreetNode>().nextNodes.Length == 0) {
                Destroy(gameObject); // destroy this game object
            }
        }*/

    }

    void OnTriggerEnter(Collider other)
    {
        //step = 0;
        NavMeshAgent agent = GetComponent<NavMeshAgent>();
        if (other.gameObject.tag == "Goal" || other.gameObject.tag == "SpecialNode")
        {
            if (other.gameObject.GetComponent<SimpleStreetNode>().nextNodes.Length == 0)
                Destroy(gameObject); // destroy this game object
            else
            {
                int num = other.gameObject.GetComponent<SimpleStreetNode>().nextNodes.Length;
                int rand = Random.Range(0, num);
                agent.SetDestination(other.gameObject.GetComponent<SimpleStreetNode>().nextNodes[rand].position);
                transform.position = other.gameObject.transform.position; // *** ADD this to fit the position
            }
        }
    }

    void OnTriggerExit(Collider other)
    {
        //step = 0;
        NavMeshAgent agent = GetComponent<NavMeshAgent>();
        if (other.gameObject.tag == "Goal" || other.gameObject.tag == "SpecialNode")
        {
            if (other.gameObject.GetComponent<SimpleStreetNode>().nextNodes.Length == 0)
                Destroy(gameObject); // destroy this game object
            else
            {
                int num = other.gameObject.GetComponent<SimpleStreetNode>().nextNodes.Length;
                int rand = Random.Range(0, num);
                agent.SetDestination(other.gameObject.GetComponent<SimpleStreetNode>().nextNodes[rand].position);
                //transform.position = other.gameObject.transform.position; // *** ADD this to fit the position
            }
        }
    }
}