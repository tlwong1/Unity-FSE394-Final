using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using TMPro;
public class SimpleTimer : MonoBehaviour
{
    public TextMeshProUGUI message;
    // Start is called before the first frame update
    void Start()
    {
        message = GetComponent<TextMeshProUGUI>();
    }

    // Update is called once per frame
    void Update()
    {
        message.text = Time.time.ToString("F2");
    }
}
