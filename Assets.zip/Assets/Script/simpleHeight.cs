using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class simpleHeight : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        //GetComponent<Renderer>().enable = False;
    }

    // Update is called once per frame
    void Update()
    {
        transform.Rotate (0, 50 * Time.deltaTime, 0);
    }
}
