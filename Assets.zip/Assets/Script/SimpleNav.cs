using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI; // add new library

public class SimpleNav : MonoBehaviour
{
    // Start is called before the first frame update
    public Transform goal;
    //int step = 0;
    void Start()
    {
        GameObject[] goals = GameObject.FindGameObjectsWithTag("Goal");
        int rand = Random.Range(0, goals.Length);

        goal = (goals[rand]).transform;

        NavMeshAgent agent = GetComponent<NavMeshAgent>();
        agent.SetDestination(goal.position);
    }

    // Update is called once per frame
    void Update()
    {
        float dis = Vector3.Distance(goal.position, this.transform.position);
        if (dis < 1)
        {
            Destroy(gameObject);
            int currNum = PlayerPrefs.GetInt("AgentNum");
            PlayerPrefs.SetInt("AgentNum", currNum++);

            //For Text Script

            //PlayerPrefs.SetInt(AgentNum, 0);
            //message.text = PlayerPrefs.GetInt(AgentNum).ToString();
        }

    }
}